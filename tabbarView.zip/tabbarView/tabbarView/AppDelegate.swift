//
//  AppDelegate.swift
//  tabbarView
//
//  Created by MAC on 02/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,UITabBarControllerDelegate {
var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        self.setupTabBar()
        return true
    }

    func setupTabBar(){
        var tabbarController = UITabBarController()
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        tabbarController = storyboard.instantiateViewController(withIdentifier: "tabbar") as! UITabBarController
        
        for navigation in tabbarController.viewControllers!{
            let nav = navigation as! UINavigationController
            let controller = nav.viewControllers[0]
            
            var strName: String = ""
            var strImg: String = ""
            if controller.isKind(of: ViewController.self){
                strName = "Coc"
                strImg = "d1"
                
            }else if controller.isKind(of: SecondVC.self) {
                strName = "Pepsi"
                strImg = "d2"
                
            }else{
                strName = "Mango"
                strImg = "d3"
            }
            
            var img = UIImage(named: strImg)
            img = img?.withRenderingMode(.alwaysTemplate)
            navigation.tabBarItem.image = img
            navigation.tabBarItem.title = strName
            navigation.tabBarItem.titlePositionAdjustment = UIOffset(horizontal: 0, vertical: -8)
            tabbarController.selectedIndex = 1
            tabbarController.tabBar.tintColor = .black
            tabbarController.tabBar.unselectedItemTintColor = UIColor.red
            self.window?.rootViewController = tabbarController
            self.window?.makeKeyAndVisible()
        }
        
    }
    
}

