//
//  ViewController.swift
//  tabbarView
//
//  Created by MAC on 02/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Coc"
        // Do any additional setup after loading the view.
    }


}

